#include<stdio.h>

float n;

int main(){
//comando de entrada
printf("Digite seu numero\n");
scanf("%f",&n);

//estrutura condicional composta
if(n<=0){
	printf("O numero %.1f e negativo.\n",n);
}  //if

else{
	printf("O numero %.1f nao e negativo.\n",n);
}

return 0;
}

