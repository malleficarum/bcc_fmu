#include<stdio.h>

float cf;

int main (){

	printf("Digite o custo de fabrica do carro:");
	scanf("%f",&cf);
	
	printf("O custo final do carro e: %.2f",cf+(cf*0.28)+(cf*0.45));

return 0;
}
