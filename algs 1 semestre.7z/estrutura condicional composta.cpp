#include<stdio.h>

int idade;

int main(){
//comando de entrada
printf("Digite sua idade\n");
scanf("%d",&idade);

//estrutura condicional composta
if(idade>=18){
	printf("Voce e maior de idade - %d anos\n",idade);
}  //if
else{
	printf("Voce e menor de idade - %d anos\n",idade);
}

return 0;
}

