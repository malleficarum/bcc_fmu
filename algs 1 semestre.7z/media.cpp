#include<stdio.h>

int main(){

float n1,n2,media;
	
//comando de entrada

printf("Digite a nota #1.\n");
scanf("%f",&n1);

printf("Digite a nota #2.\n");
scanf("%f",&n2);

//processamento
media=(n1+n2)/2;

//comando de saida
printf("\nSua media = %.1f.",media);

return 0;
}
