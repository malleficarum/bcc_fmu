#include<stdio.h>

int n;

int main(){

printf("Digite seu numero\n");
scanf("%d",&n);

if(n%2==0){
	printf("O numero %d e par.\n",n);
}  //if

else{
	printf("O numero %d nao e par.\n",n);
}

return 0;
}

