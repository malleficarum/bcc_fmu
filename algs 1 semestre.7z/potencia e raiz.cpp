#include<stdio.h>
#include<math.h>

float n;
int main (){

printf("Digite seu numero:");
scanf("%f",&n);

printf("\nNumero ao quadrado:%.2f",pow(n,2));
printf("\nNumero ao cubo:%.2f",pow(n,3));
printf("\nRaiz quadradao:%.2f",sqrt(n));
printf("\nRaiz cubica:%.2f",cbrt(n));

//pow(n,1.0/3.0) raiz cubica inversa

return 0;
}
