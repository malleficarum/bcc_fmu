#include<stdio.h>
#include<math.h>

float raio;

int main (){
	
	printf("Digite o raio do circulo:");
	scanf("%f",&raio);
	
	printf("A area do circulo e %.2f",3.1415*pow(raio,2));
	

return 0;	
}
