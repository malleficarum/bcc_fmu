#include<stdio.h>

int n, vb, vn, vv;
float pb, pn, pv;

int main (){
	
	printf("Digite o numero total de eleitores.");
	scanf("%d",&n);
	
	printf("Digite o numero de votos brancos.");
	scanf("%d",&vb);
	
	printf("Digite o numero de votos nulos.");
	scanf("%d",&vn);
	
	printf("Digite o numero de votos validos.");
	scanf("%d",&vv);
	
	pb=(vb*100)/n;
	pn=(vn*100)/n;
	pv=(vv*100)/n;
	
	printf("O percentural de votos brancos e %.2f, de votos nulos e %.2f e de votos validos e %.2f.",pb,pn,pv);
	
	return 0;
}
