#include<stdio.h> //inclui uma biblioteca (.h).

int main(){ //in�cio (int, n�mero inteiro); a chave indica o in�cio de um bloco (o principal, main).
printf("hello world!\n");
printf("cyka blyat!\n"); //printf("") � sintaxe obrigat�ria de impress�o de frase . o "\n" � um comando para pular linhas.
return 0; //o programa l� as linhas at� encontrar um n�mero o n�mero 0, que sinaliza o sucesso da sintaxe. caso houvesse algum erro, o programa retornaria ent�o o n�mero 1.
} //fim do bloco.
