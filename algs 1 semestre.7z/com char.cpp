#include<stdio.h>

char nome[40],genero; 
int idade;
float peso;

int main(){
	
//comando de entrada

printf("Qual seu nome?\n");
scanf(" %[^\n]" ,&nome);// %s n�o funciona no devc++, s� o %[^\n]

printf("E tem quantos aninhos?\n");
scanf("%d" ,&idade);

printf("Seu peso, jamantinha linda:\n");
scanf("%f" ,&peso); 

printf("Seu genero:\n");
scanf(" %[^\n]" ,&genero);


//comando de saida
printf("\nSeu nome e %s, voce tem %d anos. Seu peso e %f e seu genero e %s <3.\n",nome,idade,peso,genero);

return 0;
}
