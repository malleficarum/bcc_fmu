#include<stdio.h>

float n1, n2;

int main(){
	
	//comando de entrada
	
	printf("Digite o numero 1:");
	scanf("%f", &n1);
	
	printf("Digite o numero 2:");
	scanf("%f", &n2);
	
	//comando de saida
	
	printf("\nSoma: %.2f\n",n1+n2);
	printf("\nSubtracao: %.2f\n",n1-n2);
	printf("\nMultiplicacao: %.2f\n",n1*n2);
	printf("\nDivisao: %.2f\n",n1/n2);
	
return 0;	
}

