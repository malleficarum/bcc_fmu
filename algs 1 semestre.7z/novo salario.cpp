#include<stdio.h>

float sl;

int main (){

printf("Digite o seu salario:");
scanf("%f",&sl);

printf("O seu novo salario e: %f",sl+(sl*0.25));


return 0;
}
