#include<stdio.h>

int main (){
	
	//variaveis
	int med, min, max, at;
	
	//entrada
	printf("Qual a quantidade atual no estoque?\n");
	scanf("%d",&at);
	
	printf("Qual a quantidade maxima capaz de estar em estoque?\n");
	scanf("%d",&max);
	
	printf("Qual a quantidade minima capaz de estar em estoque?\n");
	scanf("%d",&min);
	
	med=(max+min)/2;
	
	if (at>=med){
		printf("\nNao efetuar compra.");
	}
	
	else {
		printf("\nEfetuar compra.");
	}
	
	return 0;
}
