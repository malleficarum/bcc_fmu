#include<stdio.h>

int at, an, id;

int main(){

printf("Digite o ano atual:\n");
scanf("%d",&at);

printf("Digite seu ano de nascimento:\n");
scanf("%d",&an);

id=at-an;

if(id>=16){
	printf("Voce tem %d anos e, portanto, pode votar.",id);
}  //if

else{
	printf("Voc� ainda n�o pode votar.\n",id);
}

return 0;
}

