#include<stdio.h>

float base, altura;

int main(){
	
	//comando de entrada
	printf("Digite a base de seu triangulo:");
	scanf("%f", &base);

	printf("Digite a altura de seu triangulo:");
	scanf("%f", &altura);
	
	printf("Area do triangulo: %.2f",base*altura/2);
	
return 0;	
}
